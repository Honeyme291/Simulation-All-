# Contributors

- Lara CODECA:
  - EURECOM: from June 2017 until May 2019 this project was partially funded by the French Government (National Research Agency, ANR) through the 'Investments for the Future', ref. #ANR-11-LABX-0031-01
  - Trinity College Dublin: from July 2019 this project was partially funded by the European Union’s Horizon 2020 research and innovation programme under the Marie Skłodowska-Curie grant agreement No. 713567, and ENABLE, which is funded under Science Foundation Ireland (16/SP/3804) and is co-funded under the European Regional Development Fund.
